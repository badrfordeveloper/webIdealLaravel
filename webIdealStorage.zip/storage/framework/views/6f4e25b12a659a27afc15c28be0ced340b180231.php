 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.app','data' => ['page' => 'detail-article']]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['page' => 'detail-article']); ?>

	 <!-- start page title section -->
        <section class="wow fadeIn cover-background background-position-top top-space" style="background-image:url('<?php echo e(asset('assets/images/examples/blog2.jpg')); ?>');">
            <div class="opacity-medium bg-extra-dark-gray"></div>
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-12 d-flex justify-content-center flex-column text-center page-title-large padding-30px-tb">
                        <!-- start sub title -->
                        <span class="text-white-2 opacity6 alt-font margin-10px-bottom d-block text-uppercase text-small"><?php echo e(date('Y-m-d', strtotime($post->created_at))); ?>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;<a href="blog-masonry.html" class="text-white-2"><?php echo e($post->categorie->libelle); ?></a></span>
                        <!-- end sub title -->
                        <!-- start page title -->
                        <h1 class="text-white-2 alt-font font-weight-600 margin-10px-bottom"><?php echo e($post->titre); ?></h1>
                        <!-- end page title -->
                    </div>
                </div>
            </div>
        </section>
        <!-- end page title section -->
        <!-- start section -->
        <section class="wow fadeIn padding-20px-tb border-bottom border-color-extra-light-gray">
            <div class="container">
                <div class="row">
                    <div class="col-12 breadcrumb alt-font text-small">
                        <!-- breadcrumb -->

                            <ul vocab="https://schema.org/" typeof="BreadcrumbList">
                              <li property="itemListElement" typeof="ListItem">
                                <a property="item" typeof="WebPage"
                                    href="<?php echo e(url('/')); ?>">
                                  <span property="name">Accueil</span></a>
                                <meta property="position" content="1">
                              </li>
                              ›
                              <li property="itemListElement" typeof="ListItem">
                                <a property="item" typeof="WebPage"
                                    href="<?php echo e(url('blog')); ?>">
                                  <span property="name">Blog</span></a>
                                <meta property="position" content="2">
                              </li>
                              ›
                              <li property="itemListElement" typeof="ListItem">
                                <a property="item" typeof="WebPage"
                                  href="<?php echo e(url()->current()); ?>">
                                  <span property="name"><?php echo e($post->titre); ?></span></a>
                                <meta property="position" content="3">
                              </li>
                            </ul>

                   <!--      <ul>
                       <li><a href="<?php echo e(url('/')); ?>" class="text-medium-gray">Accueil</a></li>
                       <li><a href="<?php echo e(url('blog')); ?>" class="text-medium-gray">Blog</a></li>
                       <li class="text-medium-gray"><?php echo e($post->titre); ?></li>
                   </ul> -->
                        <!-- end breadcrumb -->
                    </div>
                </div>
            </div>
        </section>
        <!-- end section -->
          <!-- start blog content section -->
        <section class="wow fadeIn" style="padding: 50px 0!important">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-lg-10 mx-auto text-center last-paragraph-no-margin">
                        <img src="<?php if($post->photo): ?> <?php echo e(asset('storage/'.$post->photo)); ?> <?php else: ?> <?php echo e(asset('assets/images/default.png')); ?> <?php endif; ?>" alt="<?php echo e($post->titre); ?>" class="width-100 margin-40px-tb md-margin-30px-tb">
                       <?php echo $post->content; ?>

                    </div>
                </div>
            </div>
        </section>
        <!-- end blog content section -->

 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\wamp64\www\webideal\resources\views/public/detail.blade.php ENDPATH**/ ?>