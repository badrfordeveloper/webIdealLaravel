 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.app','data' => ['page' => 'index']]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['page' => 'index']); ?>
        <!-- start slider section --> 
        <section class="wow fadeIn example no-padding no-transition">
            <article class="content">
                <div id="rev_slider_1078_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container" data-alias="classic4export" data-source="gallery" style="margin:0px auto;background-color:transparent;padding:0px;margin-top:0px;margin-bottom:0px;">
                    <!-- start revolution slider 5.4.1 fullwidth mode -->
                    <div id="rev_slider_1078_1" class="rev_slider fullwidthabanner" style="display:none;" data-version="5.4.1">
                        <ul><!-- slide  -->
                        <li data-index="rs-3" data-transition="fade" data-slotamount="3" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="500"  data-thumb="<?php echo e(asset('assets/images/slides/img3.jpg')); ?>"  data-rotate="0"  data-saveperformance="off"  data-title="" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                                <div class="opacity-extra-medium bg-black position-relative z-index-1"></div>
                                <!-- main image -->
                                <img src="<?php echo e(asset('assets/images/slides/img3.jpg')); ?>"  alt="Création des sites web Vitrine et Application Web"  data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="1" class="rev-slidebg" data-no-retina>
                                <!-- layer nr. 3 -->
                                <div class="tp-caption NotGeneric-Title tp-resizeme" 
                                     data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                                     data-y="['middle','middle','middle','middle']" data-voffset="['-115','-110','-90','-90']"
                                     data-fontsize="['12','12','12','12']"
                                     data-lineheight="['20','20','20','20']"
                                     data-width="none"
                                     data-height="none"
                                     data-whitespace="['nowrap','nowrap','nowrap','normal']" 
                                     data-visibility="['on', 'on', 'on', 'on']"
                                     data-type="text"
                                     data-color="['#FFF']"
                                     data-responsive_offset="on" 
                                     data-responsive="on"
                                     data-frames='[{"from":"y:50px;opacity:0;","speed":1000,"to":"o:1;","delay":300,"ease":"Power4.easeInOut"},{"delay":"wait","speed":1000,"to":"y:[175%];","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power2.easeInOut"},{"frame":"hover","speed":"300","ease":"Power1.easeInOut","to":"o:1;rX:0;rY:0;rZ:0;z:0;","style":"c:rgba(255, 255, 255, 1.00);bc:rgba(255, 255, 255, 1.00);bw:2px 2px 2px 2px;"}]'
                                     data-textAlign="['inherit', 'inherit', 'right', 'center']"
                                     data-paddingtop="[10,10,10,10]"
                                     data-paddingright="[30,30,30,30]"
                                     data-paddingbottom="[10,10,10,10]"
                                     data-paddingleft="[30,30,30,30]"
                                     data-basealign="slide" 
                                     style="z-index: 7; white-space: nowrap; text-transform: uppercase; font-family:'Montserrat', sans-serif !important; font-weight: 500; letter-spacing:2px;"> PROFITER D'UNE SOLUTION WEB</div>

                                <!-- layer nr. 4 -->
                                <div class="tp-caption NotGeneric-SubTitle tp-resizeme " 
                                     data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                                     data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" 
                                     data-fontsize="['70','70','60','50']"
                                     data-lineheight="['75','75','60','60']"
                                     data-width="none"
                                     data-height="none"
                                     data-whitespace="['nowrap','nowrap','nowrap','normal']" 
                                     data-visibility="['on', 'on', 'on', 'on']"
                                     data-type="button"
                                     data-color="['#FFF']"
                                     data-responsive_offset="on" 
                                     data-responsive="on"
                                     data-frames='[{"from":"y:50px;opacity:0;","speed":1500,"to":"o:1;","delay":600,"ease":"Power4.easeInOut"},{"delay":"wait","speed":1000,"to":"y:[175%];","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power2.easeInOut"},{"frame":"hover","speed":"300","ease":"Power1.easeInOut","to":"o:1;rX:0;rY:0;rZ:0;z:0;","style":"c:rgba(255, 255, 255, 1.00);bc:rgba(255, 255, 255, 1.00);bw:2px 2px 2px 2px;"}]'
                                     data-textAlign="['center', 'center', 'center', 'center']"
                                     data-paddingtop="[10,10,10,10]"
                                     data-paddingright="[30,30,30,30]"
                                     data-paddingbottom="[10,10,10,10]"
                                     data-paddingleft="[30,30,30,30]"
                                     data-basealign="slide" 
                                     style="z-index: 8; white-space: nowrap; font-family:'Montserrat', sans-serif !important; font-weight: 600; letter-spacing: -1px;"><!-- Chaque entreprise <br> a besoin d'un site web -->
                                       ADAPTÉE À VOS BESOINS <br/> GRÂCE À LA CRÉATIVITÉ
                                     </div>

                                <!-- layer nr. 5 -->
                                <!-- layer nr. 5 -->
                                <a href="<?php echo e(url('services')); ?>" class="tp-caption btn btn-transparent-white btn-medium border-radius-4 z-index-5" 
                                   data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                                   data-y="['middle','middle','middle','middle']" data-voffset="['130','130','110','110']" 
                                   data-fontsize="['12','14','14','14']"
                                   data-whitespace="['nowrap','nowrap','nowrap','normal']" 
                                   data-visibility="['on', 'on', 'on', 'on']"
                                   data-type="text"
                                   data-color="['#FFFFFF']"
                                   data-responsive_offset="on" 
                                   data-responsive="on"
                                   data-frames='[{"from":"y:150px;opacity:0;","speed":1500,"to":"o:1;","delay":900,"ease":"Power4.easeInOut"},{"delay":"wait","speed":1000,"to":"y:[175%];","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power2.easeInOut"},{"frame":"hover","speed":"300","ease":"Power1.easeInOut","to":"o:1;rX:0;rY:0;rZ:0;z:0;","style":"c:rgba(0, 0, 0, 1.00);bc:rgba(255, 255, 255, 1.00);bw:2px 2px 2px 2px;"}]'
                                   data-textAlign="['inherit', 'inherit', 'right', 'center']" 
                                   data-paddingtop="[6,6,6,6]"
                                   data-paddingright="[26,26,26,26]"
                                   data-paddingbottom="[6,6,6,6]"
                                   data-paddingleft="[26,26,26,26]"
                                   data-basealign="slide">Nos Services</a>
                                <!-- layer nr. 6 -->
                            </li>
                            <li data-index="rs-3045" data-transition="fade" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="Power4.easeInOut" data-easeout="Power4.easeInOut" data-masterspeed="200"  data-thumb="<?php echo e(asset('assets/images/slides/img1.jpg')); ?>"  data-rotate="0"  data-fstransition="fade" data-fsmasterspeed="100" data-fsslotamount="0" data-saveperformance="off"  data-title="" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                                <div class="opacity-extra-medium bg-black position-relative z-index-1"></div>
                                <!-- main image -->
                                <img src="<?php echo e(asset('assets/images/slides/img1.jpg')); ?>"  alt="Création des sites web Bien Coder et optimiser"  data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="1" class="rev-slidebg">
                                <!-- layer nr. 3 -->
                                <div class="tp-caption NotGeneric-Title tp-resizeme" 
                                     data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                                     data-y="['middle','middle','middle','middle']" data-voffset="['-115','-110','-90','-90']"
                                     data-fontsize="['12','12','12','12']"
                                     data-lineheight="['20','20','20','20']"
                                     data-width="none"
                                     data-height="none"
                                     data-whitespace="['nowrap','nowrap','nowrap','normal']" 
                                     data-type="text" 
                                     data-responsive_offset="on" 
                                     data-frames='[{"from":"y:50px;opacity:0;","speed":1000,"to":"o:1;","delay":300,"ease":"Power4.easeInOut"},{"delay":"wait","speed":1000,"to":"y:[175%];","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power2.easeInOut"},{"frame":"hover","speed":"300","ease":"Power1.easeInOut","to":"o:1;rX:0;rY:0;rZ:0;z:0;","style":"c:rgba(255, 255, 255, 1.00);bc:rgba(255, 255, 255, 1.00);bw:2px 2px 2px 2px;"}]'
                                     data-textAlign="['center','center','center','center']"
                                     data-paddingtop="[10,10,10,10]"
                                     data-paddingright="[0,0,0,0]"
                                     data-paddingbottom="[10,10,10,10]"
                                     data-paddingleft="[0,0,0,0]"
                                     style="z-index: 7; white-space: nowrap; text-transform: uppercase; font-family:'Montserrat', sans-serif !important; font-weight: 500; letter-spacing:2px;">Nous proposons des solutions innovantes</div>
                                <!-- layer nr. 4 -->
                                <div class="tp-caption NotGeneric-SubTitle tp-resizeme " 
                                     data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                                     data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" 
                                     data-fontsize="['70','70','60','50']"
                                     data-lineheight="['75','75','60','60']"
                                     data-width="none"
                                     data-height="none"
                                     data-whitespace="['nowrap','nowrap','nowrap','normal']" 
                                     data-type="text" 
                                     data-responsive_offset="on" 
                                     data-frames='[{"from":"y:50px;opacity:0;","speed":1000,"to":"o:1;","delay":600,"ease":"Power4.easeInOut"},{"delay":"wait","speed":1000,"to":"y:[175%];","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power2.easeInOut"},{"frame":"hover","speed":"300","ease":"Power1.easeInOut","to":"o:1;rX:0;rY:0;rZ:0;z:0;","style":"c:rgba(255, 255, 255, 1.00);bc:rgba(255, 255, 255, 1.00);bw:2px 2px 2px 2px;"}]'
                                     data-textAlign="['center','center','center','center']"
                                     data-paddingtop="[10,10,10,10]"
                                     data-paddingright="[0,0,0,0]"
                                     data-paddingbottom="[10,10,10,10]"
                                     data-paddingleft="[0,0,0,0]"
                                     style="z-index: 8; white-space: nowrap; font-family:'Montserrat', sans-serif !important; font-weight: 600; letter-spacing: -1px;">
                                     POUR MENEZ VOTRE BUSINESS<br> AU PROCHAIN NIVEAU !
                                     </div>

                                <!-- layer nr. 5 -->
                                <a href="<?php echo e(url('services')); ?>" class="tp-caption btn btn-transparent-white btn-medium border-radius-4 z-index-5" 
                                   data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                                   data-y="['middle','middle','middle','middle']" data-voffset="['130','130','110','110']" 
                                   data-fontsize="['12','14','14','14']"
                                   data-whitespace="['nowrap','nowrap','nowrap','normal']" 
                                   data-visibility="['on', 'on', 'on', 'on']"
                                   data-type="text"
                                   data-color="['#FFFFFF']"
                                   data-responsive_offset="on" 
                                   data-responsive="on"
                                   data-frames='[{"from":"y:150px;opacity:0;","speed":1500,"to":"o:1;","delay":900,"ease":"Power4.easeInOut"},{"delay":"wait","speed":1000,"to":"y:[175%];","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power2.easeInOut"},{"frame":"hover","speed":"300","ease":"Power1.easeInOut","to":"o:1;rX:0;rY:0;rZ:0;z:0;","style":"c:rgba(0, 0, 0, 1.00);bc:rgba(255, 255, 255, 1.00);bw:2px 2px 2px 2px;"}]'
                                   data-textAlign="['inherit', 'inherit', 'right', 'center']" 
                                   data-paddingtop="[6,6,6,6]"
                                   data-paddingright="[26,26,26,26]"
                                   data-paddingbottom="[6,6,6,6]"
                                   data-paddingleft="[26,26,26,26]"
                                   data-basealign="slide">Nos Services</a>
                                <!-- LAYER NR. 6 -->
                            </li>
                            <!-- slide  -->
                            <li data-index="rs-2" data-transition="fade" data-slotamount="3" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="500"  data-thumb="<?php echo e(asset('assets/images/slides/img2.jpg')); ?>"  data-rotate="0"  data-saveperformance="off"  data-title="" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                                <div class="opacity-extra-medium bg-black position-relative z-index-1"></div>
                                <!-- main image -->
                                <img src="<?php echo e(asset('assets/images/slides/img2.jpg')); ?>"  alt="Création des sites web Responsive"  data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="1" class="rev-slidebg" data-no-retina>
                                <!-- layer nr. 3 -->
                                <div class="tp-caption NotGeneric-Title tp-resizeme" 
                                     data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                                     data-y="['middle','middle','middle','middle']" data-voffset="['-115','-110','-90','-90']"
                                     data-fontsize="['12','12','12','12']"
                                     data-lineheight="['20','20','20','20']"
                                     data-width="none"
                                     data-height="none"
                                     data-whitespace="['nowrap','nowrap','nowrap','normal']" 
                                     data-visibility="['on', 'on', 'on', 'on']"
                                     data-type="text"
                                     data-color="['#FFF']"
                                     data-responsive_offset="on" 
                                     data-responsive="on"
                                     data-frames='[{"from":"y:50px;opacity:0;","speed":1000,"to":"o:1;","delay":300,"ease":"Power4.easeInOut"},{"delay":"wait","speed":1000,"to":"y:[175%];","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power2.easeInOut"},{"frame":"hover","speed":"300","ease":"Power1.easeInOut","to":"o:1;rX:0;rY:0;rZ:0;z:0;","style":"c:rgba(255, 255, 255, 1.00);bc:rgba(255, 255, 255, 1.00);bw:2px 2px 2px 2px;"}]'
                                     data-textAlign="['inherit', 'inherit', 'right', 'center']"
                                     data-paddingtop="[10,10,10,10]"
                                     data-paddingright="[30,30,30,30]"
                                     data-paddingbottom="[10,10,10,10]"
                                     data-paddingleft="[30,30,30,30]"
                                     data-basealign="slide" 
                                     style="z-index: 7; white-space: nowrap; text-transform: uppercase; font-family:'Montserrat', sans-serif !important; font-weight: 500; letter-spacing:2px;">CRÉEZ UN SITE INTERNET À VOTRE IMAGE</div>

                                <!-- layer nr. 4 -->
                                <div class="tp-caption NotGeneric-SubTitle tp-resizeme " 
                                     data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                                     data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" 
                                     data-fontsize="['70','70','60','50']"
                                     data-lineheight="['75','75','60','60']"
                                     data-width="none"
                                     data-height="none"
                                     data-whitespace="['nowrap','nowrap','nowrap','normal']" 
                                     data-visibility="['on', 'on', 'on', 'on']"
                                     data-type="button"
                                     data-color="['#FFF']"
                                     data-responsive_offset="on" 
                                     data-responsive="on"
                                     data-frames='[{"from":"y:50px;opacity:0;","speed":1500,"to":"o:1;","delay":600,"ease":"Power4.easeInOut"},{"delay":"wait","speed":1000,"to":"y:[175%];","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power2.easeInOut"},{"frame":"hover","speed":"300","ease":"Power1.easeInOut","to":"o:1;rX:0;rY:0;rZ:0;z:0;","style":"c:rgba(255, 255, 255, 1.00);bc:rgba(255, 255, 255, 1.00);bw:2px 2px 2px 2px;"}]'
                                     data-textAlign="['center', 'center', 'center', 'center']"
                                     data-paddingtop="[10,10,10,10]"
                                     data-paddingright="[30,30,30,30]"
                                     data-paddingbottom="[10,10,10,10]"
                                     data-paddingleft="[30,30,30,30]"
                                     data-basealign="slide" 
                                     style="z-index: 8; white-space: nowrap; font-family:'Montserrat', sans-serif !important; font-weight: 600; letter-spacing: -1px;"> FACILE À PRENDRE EN MAIN,<br>  MODERNE ET SÉCURISÉ</div>
                                <!-- layer nr. 5 -->
                                <a href="<?php echo e(url('services')); ?>" class="tp-caption btn btn-transparent-white btn-medium border-radius-4 z-index-5" 
                                   data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                                   data-y="['middle','middle','middle','middle']" data-voffset="['130','130','110','110']" 
                                   data-fontsize="['12','14','14','14']"
                                   data-whitespace="['nowrap','nowrap','nowrap','normal']" 
                                   data-visibility="['on', 'on', 'on', 'on']"
                                   data-type="text"
                                   data-color="['#FFFFFF']"
                                   data-responsive_offset="on" 
                                   data-responsive="on"
                                   data-frames='[{"from":"y:150px;opacity:0;","speed":1500,"to":"o:1;","delay":900,"ease":"Power4.easeInOut"},{"delay":"wait","speed":1000,"to":"y:[175%];","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power2.easeInOut"},{"frame":"hover","speed":"300","ease":"Power1.easeInOut","to":"o:1;rX:0;rY:0;rZ:0;z:0;","style":"c:rgba(0, 0, 0, 1.00);bc:rgba(255, 255, 255, 1.00);bw:2px 2px 2px 2px;"}]'
                                   data-textAlign="['inherit', 'inherit', 'right', 'center']" 
                                   data-paddingtop="[6,6,6,6]"
                                   data-paddingright="[26,26,26,26]"
                                   data-paddingbottom="[6,6,6,6]"
                                   data-paddingleft="[26,26,26,26]"
                                   data-basealign="slide">Nos Services</a>
                                <!-- layer nr. 6 -->
                            </li>
                            
                        </ul>
                    </div>
                </div>
                <!-- end revolution slider -->
            </article>
        </section>
        <!-- end slider section -->
        <!-- start about section --> 
        <section class="wow fadeIn cover-background md-no-background-img bg-medium-light-gray" style="background-image: url('<?php echo e(asset('assets/images/banner-bg1.jpg')); ?>')">
            <div class="container">
                <div class="row"> 
                    <div class="col-12 col-lg-6 offset-lg-6 wow fadeIn">
                        <div class="row m-0">
                            <div class="col-12 text-center text-lg-left sm-no-padding-lr last-paragraph-no-margin margin-60px-bottom md-margin-30px-bottom"> 
                                <span class="text-medium text-deep-pink alt-font margin-10px-bottom d-inline-block"></span>
                                <h5 class="alt-font text-extra-dark-gray font-weight-600">Qui Sommes Nous</h5>
                                <p>
                                    Nous sommes une équipe des informaticiens expert, créative, et dynamique qui vont vous offrir des services professionnels dans la conception et la création des sites Internet et des applications web.
                                </p>
                                <p>
                                    Notre objectif est la satisfaction de tous nos clients, et de mettre tous nos savoir-faire pour vous accompagner vers la réussite dans de vos projets informatiques
                                </p>
                            </div>                          
                            <!-- star feature box item -->
                            <div class="col-12 col-md-6 sm-margin-30px-bottom last-paragraph-no-margin sm-no-padding-lr text-center ">
                            <i class="icon-browser text-deep-pink icon-extra-medium margin-20px-bottom md-margin-15px-bottom "></i>
                                <div class="feature-content">
                                    <div class="alt-font font-weight-600 text-extra-dark-gray margin-5px-bottom">Création des sites internet</div>
                                    
                                </div>
                            </div>
                            <!-- end feature box item -->
                            <!-- star feature box item -->
                            <div class="col-12 col-md-6 last-paragraph-no-margin sm-no-padding-lr text-center ">
                                <i class="icon-laptop text-deep-pink icon-extra-medium margin-20px-bottom md-margin-15px-bottom"></i>
                                <div class="feature-content">
                                    <div class="alt-font font-weight-600 text-extra-dark-gray margin-5px-bottom">Création des applications web</div>
                                    
                                </div> 
                            </div>
                            <!-- end feature box item -->
                        </div>
                    </div> 
                </div>
            </div>
        </section>
        <!-- end about section -->
        <!-- start services section -->
        <section class="wow fadeIn">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12 col-lg-8 margin-eight-bottom text-center last-paragraph-no-margin">
                        <h5 class="alt-font text-extra-dark-gray font-weight-600">Nous fournissons des services de développement Web de haute qualité et rentables</h5>
                        
                </div>
                <div class="row">
                    <!-- start services item -->
                    <div class="col-12 col-lg-3 col-md-6 md-margin-four-bottom sm-margin-eight-bottom wow fadeInUp last-paragraph-no-margin" style="visibility: visible; animation-name: fadeInUp;">
                        <div class="bg-white box-shadow-light text-center padding-eighteen-tb feature-box-8 position-relative z-index-5">
                            <div class="d-inline-block margin-20px-bottom"><i class="icon-desktop text-white-2 icon-round-small bg-deep-pink"></i></div>
                            <div class="alt-font text-extra-dark-gray font-weight-600 margin-10px-bottom">Application web</div>
                            <p class="width-75 lg-width-90 mx-auto">Notre équipe développe des solutions et des applications web sur mesure qui répondent au besoin de chaque projet , quel que soit votre métier et sous différents langages.</p>
                            <div class="feature-box-overlay bg-deep-pink"></div>
                        </div>
                    </div>
                    <!-- end services item -->
                    <!-- start services item -->
                    <div class="col-12 col-lg-3 col-md-6 md-margin-four-bottom sm-margin-eight-bottom wow fadeInUp last-paragraph-no-margin" data-wow-delay="0.2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">
                        <div class="bg-white box-shadow-light text-center padding-eighteen-tb feature-box-8 position-relative z-index-5">
                            <div class="d-inline-block margin-20px-bottom"><i class="icon-browser text-white-2 icon-round-small bg-deep-pink"></i></div>
                            <div class="alt-font text-extra-dark-gray font-weight-600 margin-10px-bottom">Sites internet</div>
                            <p class="width-75 lg-width-90 mx-auto">Nous créons different types des sites : Vitrine , É-commerce , Catalogue  .. adaptés à vos besoins.proposer vos services de manière flexible, pratique et polyvalente.</p>
                            <div class="feature-box-overlay bg-deep-pink"></div>
                        </div>
                    </div>
                    <!-- end services item -->
                    <!-- start services item -->
                    <div class="col-12 col-lg-3 col-md-6 sm-margin-eight-bottom wow fadeInUp last-paragraph-no-margin" data-wow-delay="0.4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInUp;">
                        <div class="bg-white box-shadow-light text-center padding-eighteen-tb feature-box-8 position-relative z-index-5">
                            <div class="d-inline-block margin-20px-bottom"><i class="icon-presentation text-white-2 icon-round-small bg-deep-pink"></i></div>
                            <div class="alt-font text-extra-dark-gray font-weight-600 margin-10px-bottom">SEO Marketing</div>
                            <p class="width-75 lg-width-90 mx-auto">La visibilité de votre site web sur Google est primordiale pour votre développement. Notre équipe met en place une stratégie SEO et référencement efficace et innovante</p>
                            <div class="feature-box-overlay bg-deep-pink"></div>
                        </div>
                    </div>
                    <!-- end services item -->
                    <!-- start services item -->
                    <div class="col-12 col-lg-3 col-md-6 wow fadeInUp last-paragraph-no-margin" data-wow-delay="0.6s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInUp;">
                        <div class="bg-white box-shadow-light text-center padding-eighteen-tb feature-box-8 position-relative z-index-5">
                            <div class="d-inline-block margin-20px-bottom"><i class="icon-tools text-white-2 icon-round-small bg-deep-pink"></i></div>
                            <div class="alt-font text-extra-dark-gray font-weight-600 margin-10px-bottom">Conception Graphique</div>
                            <p class="width-75 lg-width-90 mx-auto">Le logo ou logotype est la base de votre identité visuelle. C’est votre logo qui donne l’image de votre société et c’est la première chose que l’on voit de votre entreprise.</p>
                            <div class="feature-box-overlay bg-deep-pink"></div>
                        </div>
                    </div>
                    <!-- end services item -->
                </div>
            </div>
        </section>
        <!-- end services section -->
        <!-- start section -->
        <section class="p-0 wow fadeIn">
            <div class="container-fluid">
                <div class="row">
                    <!-- start features item -->
                    <div class="col-12 col-lg-3 p-0 cover-background position-relative md-height-500px sm-height-300px wow fadeIn" style="background: transparent url('<?php echo e(asset('assets/images/examples/equipe.jpg')); ?>')"></div>
                    <!-- end features item -->
                    <!-- start features item -->
                    <div class="col-12 col-lg-3 p-0 d-flex align-items-center position-relative bg-extra-dark-gray text-center text-lg-left wow fadeIn" data-wow-delay="0.2s">
                        <div class="padding-fifteen-all lg-padding-ten-all sm-padding-30px-all width-100">
                            <div class="alt-font text-medium-gray margin-10px-bottom"></div>
                            <div class="alt-font text-extra-large margin-20px-bottom text-white-2 width-90 lg-width-100 sm-margin-15px-bottom">Équipe expérimentée en création des sites web</div>
                            <p>WEBIDEAL dispose d’une équipe aux disciplines variées et aux connaissance larges dans le domaine de la création de sites web , capable de comprendre votre besoin et vous proposer les meilleures solutions.</p>
                            <!-- <a href="about-us-simple.html" class="btn btn-transparent-white btn-small border-radius-4"><i class="fas fa-play-circle icon-very-small margin-5px-right ml-0" aria-hidden="true"></i>Read More</a> -->
                        </div>
                    </div>
                    <!-- end features item -->
                    <!-- start features item -->
                    <div class="col-12 col-lg-3 p-0 cover-background position-relative md-height-500px sm-height-300px wow fadeIn" data-wow-delay="0.4s" style="background: transparent url('<?php echo e(asset('assets/images/examples/productivite.jpg')); ?>')"></div>
                    <!-- end features item -->
                    <!-- start features item -->
                    <div class="col-12 col-lg-3 p-0 d-flex align-items-center position-relative bg-extra-dark-gray text-center text-lg-left wow fadeIn" data-wow-delay="0.6s">
                        <div class="padding-fifteen-all lg-padding-ten-all sm-padding-30px-all width-100">
                            <div class="alt-font text-medium-gray margin-10px-bottom"></div>
                            <div class="alt-font text-extra-large margin-20px-bottom text-white-2 width-90 lg-width-100 sm-margin-15px-bottom">Rapidité et proactivité</div>
                            <p>Notre équipe réactive est toujours disponible pour répondre à vos exigences les plus pointues. Nous vous livrons vos sites web dans un délai très rapide avec des résultats qui conviennent à vos attentes.</p>
                            <!-- <a href="about-us-classic.html" class="btn btn-transparent-white btn-small border-radius-4"><i class="fas fa-play-circle icon-very-small margin-5px-right ml-0" aria-hidden="true"></i>Read More</a> -->
                        </div>
                    </div>
                    <!-- end features item -->
                </div>
            </div>
        </section>
        <!-- end section -->
        <!-- start portfolio section -->
        <!-- start portfolio section -->
        <section class="wow fadeIn padding-90px-top md-padding-50px-top sm-padding-30px-top">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <!-- start filter navigation -->
                        <ul class="portfolio-filter nav nav-tabs justify-content-center border-0 portfolio-filter-tab-1 font-weight-600 alt-font text-uppercase text-center margin-80px-bottom text-small md-margin-40px-bottom sm-margin-20px-bottom">
                            <li class="nav active"><a href="javascript:void(0);" data-filter="*" class="light-gray-text-link text-very-small">Tous</a></li>
                            <li class="nav"><a href="javascript:void(0);" data-filter=".vitrine" class="light-gray-text-link text-very-small">Vitrine</a></li>
                            <li class="nav"><a href="javascript:void(0);" data-filter=".catalogue" class="light-gray-text-link text-very-small">Catalogue</a></li>
                            <li class="nav"><a href="javascript:void(0);" data-filter=".ecommerce" class="light-gray-text-link text-very-small">E-commerce</a></li>
                            <li class="nav"><a href="javascript:void(0);" data-filter=".application" class="light-gray-text-link text-very-small">Application Web</a></li>
                        </ul>                                                                           
                        <!-- end filter navigation -->
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-12 px-0 sm-padding-15px-lr">
                        <div class="filter-content overflow-hidden">
                        <ul class="portfolio-grid work-4col gutter-medium hover-option10 lightbox-portfolio">
                                <li class="grid-sizer"></li>
                                <!-- start portfolio item -->
                                <li class="grid-item catalogue wow zoomIn">
                                    <figure>
                                        <div class="portfolio-img bg-black"><img src="<?php echo e(asset('assets/images/portfolio275/imageportfoliocatalogue1.jpg')); ?>" alt="Portfolio de Site web Catalogue"/></div>
                                        <figcaption>
                                            <div class="portfolio-hover-main">
                                                <div class="portfolio-hover-box align-middle">
                                                    <div class="portfolio-icon">
                                                        <!--<a href="single-project-page-01.html"><i class="fas fa-link" aria-hidden="true"></i></a>-->
                                                        <a class="gallery-link" title="IMAGE TITLE" href="<?php echo e(asset('assets/images/portfolio/imageportfoliocatalogue1.jpg')); ?>"><i class="fas fa-search" aria-hidden="true"></i></a>
                                                    </div>
                                                    <div class="portfolio-hover-content">
                                                        <span class="font-weight-600 line-height-normal alt-font text-white-2 text-uppercase margin-5px-bottom d-block">Herbal Beauty Salon</span>
                                                        <!-- <p class="text-medium-gray text-uppercase text-extra-small mb-0">Branding and Brochure</p> -->
                                                    </div>
                                                </div>
                                            </div>
                                        </figcaption>
                                    </figure>
                                </li>
                                <!-- end portfolio item -->
                                <!-- start portfolio item -->
                                <li class="grid-item vitrine wow zoomIn" data-wow-delay="0.2s">
                                    <figure>
                                        <div  class="portfolio-img bg-black"><img src="<?php echo e(asset('assets/images/portfolio275/imageportfoliositevitrine4.jpg')); ?>" alt="Portfolio de Site web Vitrine"/></div>
                                        <figcaption>
                                            <div class="portfolio-hover-main">
                                                <div class="portfolio-hover-box align-middle">
                                                    <div class="portfolio-icon">
                                                        <!-- <a href="single-project-page-02.html"><i class="fas fa-link" aria-hidden="true"></i></a>  -->
                                                        <a class="gallery-link" title="IMAGE TITLE" href="<?php echo e(asset('assets/images/portfolio/imageportfoliositevitrine4.jpg')); ?>"><i class="fas fa-search" aria-hidden="true"></i></a>  
                                                    </div>
                                                    <div class="portfolio-hover-content">
                                                        <span class="font-weight-600 line-height-normal alt-font text-white-2 text-uppercase margin-5px-bottom d-block">Tailoring Interior</span>
                                                        <!-- <p class="text-medium-gray text-uppercase text-extra-small mb-0">Branding and Identity</p> -->
                                                    </div>
                                                </div>
                                            </div>
                                        </figcaption>
                                    </figure>
                                </li>
                                <!-- end portfolio item -->
                          
                                <!-- start portfolio item -->
                                <li class="grid-item application wow zoomIn">
                                    <figure>
                                        <div  class="portfolio-img bg-black"><img src="<?php echo e(asset('assets/images/portfolio275/imageportfoliocommandeenligne.jpg')); ?>" alt=" Portfolio de Site web E-commerce"/></div>
                                        <figcaption>
                                            <div class="portfolio-hover-main">
                                                <div class="portfolio-hover-box align-middle">
                                                    <div class="portfolio-icon">         
                                                       <!--  <a href="single-project-page-04.html"><i class="fas fa-link" aria-hidden="true"></i></a>   -->    
                                                        <a class="gallery-link" title="IMAGE TITLE" href="<?php echo e(asset('assets/images/portfolio/imageportfoliocommandeenligne.jpg')); ?>"><i class="fas fa-search" aria-hidden="true"></i></a>   
                                                    </div>
                                                    <div class="portfolio-hover-content">
                                                        <span class="font-weight-600 line-height-normal alt-font text-white-2 text-uppercase margin-5px-bottom d-block">HardDot Stone</span>
                                                        <!-- <p class="text-medium-gray text-uppercase text-extra-small mb-0">Branding and Identity</p> -->
                                                    </div>
                                                </div>
                                            </div>
                                        </figcaption>
                                    </figure>
                                </li>
                                <!-- end portfolio item -->
                                <!-- start portfolio item -->
                                <li class="grid-item vitrine wow zoomIn" data-wow-delay="0.2s">
                                    <figure>
                                        <div  class="portfolio-img bg-black"><img src="<?php echo e(asset('assets/images/portfolio275/imageportfoliositevitrine2.jpg')); ?>" alt="Portfolio de Site web Vitrine 2"/></div>
                                        <figcaption>
                                            <div class="portfolio-hover-main">
                                                <div class="portfolio-hover-box align-middle">
                                                    <div class="portfolio-icon">                              
                                                        <!-- <a href="single-project-page-05.html"><i class="fas fa-link" aria-hidden="true"></i></a>  -->  
                                                        <a class="gallery-link" title="IMAGE TITLE" href="<?php echo e(asset('assets/images/portfolio/imageportfoliositevitrine2.jpg')); ?>"><i class="fas fa-search" aria-hidden="true"></i></a>   
                                                    </div>
                                                    <div class="portfolio-hover-content">
                                                        <span class="font-weight-600 line-height-normal alt-font text-white-2 text-uppercase margin-5px-bottom d-block">Crop Identity</span>
                                                        <!-- <p class="text-medium-gray text-uppercase text-extra-small mb-0">Branding and Brochure</p> -->
                                                    </div>
                                                </div>
                                            </div>
                                        </figcaption>
                                    </figure>
                                </li>
                                <!-- end portfolio item -->
                                <!-- start portfolio item -->
                                <li class="grid-item ecommerce wow zoomIn">
                                    <figure>
                                        <div  class="portfolio-img bg-black"><img src="<?php echo e(asset('assets/images/portfolio275/imageportfolioecommerce3.jpg')); ?>" alt="Portfolio de Site web E-commerce 2"/></div>
                                        <figcaption>
                                            <div class="portfolio-hover-main">
                                                <div class="portfolio-hover-box align-middle">
                                                    <div class="portfolio-icon">                            
                                                        <!--<a href="single-project-page-01.html"><i class="fas fa-link" aria-hidden="true"></i></a>-->     
                                                        <a class="gallery-link" title="IMAGE TITLE" href="<?php echo e(asset('assets/images/portfolio/imageportfolioecommerce3.jpg')); ?>"><i class="fas fa-search" aria-hidden="true"></i></a>  
                                                    </div>
                                                    <div class="portfolio-hover-content">
                                                        <span class="font-weight-600 line-height-normal alt-font text-white-2 text-uppercase margin-5px-bottom d-block">Violator Series</span>
                                                        <!-- <p class="text-medium-gray text-uppercase text-extra-small mb-0">Web and Photography</p> -->
                                                    </div>
                                                </div>
                                            </div>
                                        </figcaption>
                                    </figure>
                                </li>
                                <!-- end portfolio item -->
                                <!-- start portfolio item -->
                                <li class="grid-item ecommerce wow zoomIn" data-wow-delay="0.4s">
                                    <figure>
                                        <div  class="portfolio-img bg-black"><img src="<?php echo e(asset('assets/images/portfolio275/imageportfolioecommerce1.jpg')); ?>" alt="Portfolio de Site web E-commerce 3"/></div>
                                        <figcaption>
                                            <div class="portfolio-hover-main">
                                                <div class="portfolio-hover-box align-middle">
                                                    <div class="portfolio-icon">                                           
                                                        <!-- <a href="single-project-page-02.html"><i class="fas fa-link" aria-hidden="true"></i></a>  -->      
                                                        <a class="gallery-link" title="IMAGE TITLE" href="<?php echo e(asset('assets/images/portfolio/imageportfolioecommerce1.jpg')); ?>"><i class="fas fa-search" aria-hidden="true"></i></a> 
                                                    </div>
                                                    <div class="portfolio-hover-content">
                                                        <span class="font-weight-600 line-height-normal alt-font text-white-2 text-uppercase margin-5px-bottom d-block">Jeremy Dupont</span>
                                                        <!-- <p class="text-medium-gray text-uppercase text-extra-small mb-0">Branding and Identity</p> -->
                                                    </div>
                                                </div>
                                            </div>
                                        </figcaption>
                                    </figure>
                                </li>
                                <!-- end portfolio item -->
                                <!-- start portfolio item -->
                                <li class="grid-item ecommerce wow zoomIn" data-wow-delay="0.4s">
                                    <figure>
                                        <div  class="portfolio-img bg-black"><img src="<?php echo e(asset('assets/images/portfolio275/imageportfolioecommerce4.jpg')); ?>" alt=" Portfolio de Site web E-commerce 3"/></div>
                                        <figcaption>
                                            <div class="portfolio-hover-main">
                                                <div class="portfolio-hover-box align-middle">
                                                    <div class="portfolio-icon">                                              
                                                        <!-- <a href="single-project-page-03.html"><i class="fas fa-link" aria-hidden="true"></i></a>   -->  
                                                        <a class="gallery-link" title="IMAGE TITLE" href="<?php echo e(asset('assets/images/portfolio/imageportfolioecommerce4.jpg')); ?>"><i class="fas fa-search" aria-hidden="true"></i></a>  
                                                    </div>
                                                    <div class="portfolio-hover-content">
                                                        <span class="font-weight-600 line-height-normal alt-font text-white-2 text-uppercase margin-5px-bottom d-block">The Aparthotel</span>
                                                        <!-- <p class="text-medium-gray text-uppercase text-extra-small mb-0">Web and Photography</p> -->
                                                    </div>
                                                </div>
                                            </div>
                                        </figcaption>
                                    </figure>
                                </li>
                                <!-- end portfolio item -->
                              
                            
                             <!-- start portfolio item -->
                                <li class="grid-item application wow zoomIn" data-wow-delay="0.4s">
                                    <figure>
                                        <div  class="portfolio-img bg-black"><img src="<?php echo e(asset('assets/images/portfolio275/imageportfolioecommerce2.jpg')); ?>" alt="Portfolio de Site web E-commerce 4"/></div>
                                        <figcaption>
                                            <div class="portfolio-hover-main">
                                                <div class="portfolio-hover-box align-middle">
                                                    <div class="portfolio-icon">                                              
                                                        <!-- <a href="single-project-page-03.html"><i class="fas fa-link" aria-hidden="true"></i></a>   -->  
                                                        <a class="gallery-link" title="IMAGE TITLE" href="<?php echo e(asset('assets/images/portfolio/imageportfolioecommerce2.jpg')); ?>"><i class="fas fa-search" aria-hidden="true"></i></a>  
                                                    </div>
                                                    <div class="portfolio-hover-content">
                                                        <span class="font-weight-600 line-height-normal alt-font text-white-2 text-uppercase margin-5px-bottom d-block">The Aparthotel</span>
                                                        <!-- <p class="text-medium-gray text-uppercase text-extra-small mb-0">Web and Photography</p> -->
                                                    </div>
                                                </div>
                                            </div>
                                        </figcaption>
                                    </figure>
                                </li>
                                <!-- end portfolio item -->
                            
                            
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end portfolio section -->
                <!-- start parallax section -->
        <section class="parallax bg-extra-dark-gray" data-stellar-background-ratio="0.6" >
            <div class="opacity-medium bg-extra-dark-gray"></div>
            <div class="container-fluid position-relative">
                <div class="row align-items-center"> 
                    <div class="col-12 col-lg-6 text-center md-margin-50px-bottom sm-margin-30px-bottom wow fadeIn">
                        <img src="<?php echo e(asset('assets/images/homepage-option15-image-3.png')); ?>" alt="Ce qui nous distingue" class="w-100">
                    </div> 
                    <div class="col-12 col-lg-6 wow fadeIn" data-wow-delay="0.2s">
                        <div class="width-75 lg-width-100 padding-three-lr sm-no-padding-lr">
                            <h4 class="alt-font text-white-2 font-weight-600">Ce qui nous distingue </h4>
                       
                            <ul class="p-0 list-style-4 margin-30px-bottom list-style-color">
                            <li>Interface utilisateur belle et facile à comprendre, animations professionnelles</li>
                            <li>Les avantages du thème sont une conception parfaite des pixels et un code claire fourni</li>
                            <li>Présentez vos services de manière flexible, pratique et polyvalente</li>
                            <li>Trouvez plus d'idées créatives pour vos projets </li>
                            <li>Puissance illimitée et possibilités de personnalisation</li> 
                            </ul>
                            <a href="<?php echo e(url('portfolio')); ?>" class="btn btn-dark-gray btn-small text-extra-small border-radius-4 margin-20px-top"><i class="fas fa-play-circle icon-very-small margin-5px-right ml-0" aria-hidden="true"></i> Voir Portfolio</a>
                       </div>
                    </div> 
                </div>
            </div>
        </section>
        <!-- end parallax section -->

        <!-- start parallax feature box -->
        <section class="p-0 wow fadeIn bg-light-gray">
            <div class="container-fluid">
                <div class="row"> 
                    <div class="col-12 col-lg-6 wow fadeInLeft padding-four-all md-padding-eight-all md-padding-15px-lr sm-padding-50px-tb">
                        <div class="row m-0">
                            <div class="col-12 col-xl-10 margin-six-bottom lg-margin-six-bottom md-margin-30px-bottom sm-no-margin-bottom">
                                <h4 class="alt-font text-extra-dark-gray font-weight-600 text-center text-lg-left md-width-70 mx-auto mx-lg-0 sm-width-100 sm-margin-30px-bottom">NOS VALEURS</h4>
                            </div>
                            <!-- start feature box item -->
                            <div class="col-12 col-xl-6 col-lg-12 col-md-6 margin-six-bottom md-margin-30px-bottom last-paragraph-no-margin">
                                <div class="feature-box-5 position-relative">
                                    <i class="icon-desktop text-medium-gray icon-medium"></i>
                                    <div class="feature-content">
                                        <div class="text-extra-dark-gray margin-5px-bottom alt-font font-weight-600">Proximité</div>
                                        <p class="width-95 sm-width-100">En plaçant la relation et la satisfaction client au cœur de nos process, et la garantie de la disponibilité de ses collaborateurs pour réaliser le projet dans les délais impartis.</p>
                                    </div>
                                </div>
                            </div>
                            <!-- end feature box item -->
                            <!-- start feature box item -->
                            <div class="col-12 col-xl-6 col-lg-12 col-md-6 lg-margin-six-bottom md-no-margin-bottom sm-margin-30px-bottom last-paragraph-no-margin">
                                <div class="feature-box-5 position-relative">
                                    <i class="icon-wallet text-medium-gray icon-medium"></i>
                                    <div class="feature-content">
                                        <div class="text-extra-dark-gray margin-5px-bottom alt-font font-weight-600">Innovation</div>
                                        <p class="width-95 sm-width-100">En s’adaptant et en étant réactif face aux grands changements , parcequ'il est plus importante pour une agence de développement agile que le suivi d’un plan.</p>
                                    </div>
                                </div>
                            </div>
                            <!-- end feature box item -->
                            <!-- start feature box item -->
                            <div class="col-12 col-xl-6 col-lg-12 col-md-6 margin-six-bottom md-margin-30px-bottom last-paragraph-no-margin">
                                <div class="feature-box-5 position-relative">
                                    <i class="icon-book-open text-medium-gray icon-medium"></i>
                                    <div class="feature-content">
                                        <div class="text-extra-dark-gray margin-5px-bottom alt-font font-weight-600">Qualité</div>
                                        <p class="width-95 sm-width-100">Pour garantir la pérennité des prestations livrées ,et livrer une bonne conception et un code de qualité à ses clients.</p>
                                    </div>
                                </div>
                            </div>
                            <!-- end feature box item -->
                            <!-- start feature box item -->
                            <div class="col-12 col-xl-6 col-lg-12 col-md-6 last-paragraph-no-margin">
                                <div class="feature-box-5 position-relative ">
                                    <i class="icon-camera text-medium-gray icon-medium"></i>
                                    <div class="feature-content">
                                        <div class="text-extra-dark-gray margin-10px-bottom alt-font font-weight-600">Enthousiasme</div>
                                        <p class="width-95 sm-width-100">N s’assurons que ses collaborateurs améliorent leurs compétences en continue pour qu’ils développent des projets de qualité.</p>
                                    </div>
                                </div>
                            </div>
                            <!-- end feature box item -->
                            
                            
                            
                        </div>
                    </div> 
                    <div class="col-12 col-lg-6 cover-background md-height-400px wow fadeInRight" style="background-image:url('<?php echo e(asset('assets/images/examples/beautifuldigital.jpg')); ?>');"></div>
                </div>
            </div>
        </section>
        <!-- end parallax feature box -->   


        <!-- start video section http://placehold.it/1920x1100-->
        <section class="parallax" data-stellar-background-ratio="0" style="background-image:url('<?php echo e(asset('assets/images/examples/internet-4463031_1920.jpg')); ?>');">
            <div class="opacity-full bg-extra-dark-gray"></div>
            <div class="container position-relative">
                <div class="row justify-content-center">
                    <div class="col-12 col-xl-9 col-lg-10 text-center wow fadeIn last-paragraph-no-margin">
                        <a class="popup-youtube" href="https://www.youtube.com/watch?v=nrJtHemSPW4"><img src="<?php echo e(asset('assets/images/icon-play-white.png')); ?>" class="width-10 sm-width-50px margin-30px-bottom" alt="icon start"/></a>
                        <h4 class="alt-font text-white-2">Interface utilisateur belle et facile à utiliser, animations professionnelles et fonction glisser-déposer</h4>
                        <p class="width-75 mx-auto text-medium-gray lg-width-90 sm-width-100 sm-margin-30px-bottom">Avec des années d'expérience dans le secteur de la conception et du développement de sites Web, nous sommes fiers de créer des conceptions uniques, créatives et de qualité qui sont développées selon les dernières techniques de codage et de développement modernes, qui sont ensuite construites en utilisant le cadre de codage structuré le plus récent afin que votre équipe de développement peut facilement passer au niveau supérieur.</p>
                        <a href="<?php echo e(url('apropos')); ?>" class="btn btn-white btn-small text-extra-small border-radius-4 margin-45px-top sm-no-margin-top"><i class="fas fa-play-circle icon-very-small margin-5px-right ml-0" aria-hidden="true"></i> A Propos</a>
                    </div>
                </div>
            </div>
        </section>
        <!-- end video section -->
        <!-- start testimonial slider section -->
        <section class="bg-light-gray wow fadeIn">
            <div class="container">
                <div class="row">
                    <div class="col-12 text-center wow fadeIn">
                        <h5 class="text-uppercase alt-font text-extra-dark-gray margin-20px-bottom font-weight-700 md-width-100">Témoignages clients</h5>
                        <span class="separator-line-horrizontal-medium-light2 bg-deep-pink d-table mx-auto width-100px"></span>
                    </div>
                </div>
                <div class="row">
                            <div class="col-12 col-lg-4 md-margin-two-bottom wow fadeIn last-paragraph-no-margin testimonial-style3">
                                <div class="testimonial-content-box padding-twelve-all bg-white border-radius-6 box-shadow arrow-bottom md-padding-seven-all sm-padding-eight-all">
                                    Un grand merci à vous pour leur réactivité et la qualité de leurs prestations proposées. Ce que j’apprécie, c’est le professionnalisme et l’écoute dont fait preuve votre équipe, le tout dans un esprit pro et amical.
                                </div>
                                <!-- start testimonials item -->
                                <div class="testimonial-box padding-25px-all sm-padding-20px-all">
                                    <div class="image-box width-20"><img src="<?php echo e(asset('assets/images/user.png')); ?>" class="rounded-circle" alt="icon user"></div>
                                    <div class="name-box padding-20px-left">
                                        <div class="alt-font font-weight-600 text-small text-uppercase text-extra-dark-gray">Shoko Mugikura</div>
                                        <p class="text-extra-small text-uppercase text-medium-gray">Graphic Designer</p>
                                    </div>
                                </div>
                            </div>
                            <!-- end testimonials item -->
                            <!-- start testimonials item -->
                            <div class="col-12 col-lg-4 sm-margin-two-bottom wow fadeIn last-paragraph-no-margin testimonial-style3" data-wow-delay="0.2s">
                                <div class="testimonial-content-box padding-twelve-all bg-white border-radius-6 box-shadow arrow-bottom md-padding-seven-all sm-padding-eight-all">
                                    Bonjour, c’est exactement ce que j’attendais. Je n ‘ai qu’un mot à dire : SUPER TRAVAIL. Vous pouvez mettre en production les déclinaisons ! Je tiens à vous remercier sincèrement pour votre très grande réactivité cette proposition
                                </div>
                                <div class="testimonial-box padding-25px-all sm-padding-20px-all">
                                    <div class="image-box width-20"><img src="<?php echo e(asset('assets/images/user.png')); ?>" class="rounded-circle" alt="icon user"></div>
                                    <div class="name-box padding-20px-left">
                                        <div class="alt-font font-weight-600 text-small text-uppercase text-extra-dark-gray">Alexander Harvard</div>
                                        <p class="text-extra-small text-uppercase text-medium-gray">Creative Director</p>
                                    </div>
                                </div>
                            </div>
                            <!-- end testimonials item -->
                            <!-- start testimonials item -->
                            <div class="col-12 col-lg-4 wow fadeIn last-paragraph-no-margin testimonial-style3" data-wow-delay="0.4s">
                                <div class="testimonial-content-box padding-twelve-all bg-white border-radius-6 box-shadow arrow-bottom md-padding-seven-all sm-padding-eight-all">
                                    Je tiens à vivement remercier votre équipe car elle a su à chaque fois faire preuve de réactivité et d’un esprit artistique digne des plus grands.Vos précieux conseils nous ont été d’une grande aide et nous souhaiterions vous solliciter bien plus souvent.
                                </div>
                                <div class="testimonial-box padding-25px-all sm-padding-20px-all">
                                    <div class="image-box width-20"><img src="<?php echo e(asset('assets/images/user.png')); ?>" class="rounded-circle" alt="icon user"></div>
                                    <div class="name-box padding-20px-left">
                                        <div class="alt-font font-weight-600 text-small text-uppercase text-extra-dark-gray">Herman Miller</div>
                                        <p class="text-extra-small text-uppercase text-medium-gray">Co Founder / CEO</p>
                                    </div>
                                </div>
                            </div>
                            <!-- end testimonials item -->
                        </div>
            </div>
        </section>
        <!-- end testimonial slider section -->
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\wamp64\www\webideal\resources\views/public/index.blade.php ENDPATH**/ ?>