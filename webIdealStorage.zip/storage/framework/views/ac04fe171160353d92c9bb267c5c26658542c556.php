<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">


<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	 <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<title>Login</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
	<link href='https://fonts.googleapis.com/css?family=Raleway' rel='stylesheet'>

	   <link href="<?php echo e(asset('admin/assets/css/login.css')); ?>" rel="stylesheet">
</head>
<body>
	<?php echo $__env->yieldContent('content'); ?>

</body>


</html><?php /**PATH D:\C\wamp64\www\webideal2\resources\views/layouts/auth.blade.php ENDPATH**/ ?>