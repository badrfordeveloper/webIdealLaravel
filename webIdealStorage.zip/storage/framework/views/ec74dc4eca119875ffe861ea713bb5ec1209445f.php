 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.app','data' => ['page' => 'blog']]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['page' => 'blog']); ?>
        <!-- start page title section -->
        <section class="wow fadeIn cover-background background-position-top top-space" style="background-image:url('<?php echo e(asset('assets/images/examples/blog2.jpg')); ?>');">
            <div class="opacity-medium bg-extra-dark-gray"></div>
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-12 d-flex flex-column text-center justify-content-center page-title-large padding-30px-tb">
                        <!-- start sub title -->
                        <!-- <span class="d-block text-white-2 opacity6 alt-font margin-5px-bottom">We are awesome designer</span> -->
                        <!-- end sub title -->
                        <!-- start page title -->
                        <h1 class="alt-font text-white-2 font-weight-600 mb-0" style="margin-top: 19px;font-size: 27pt;">Blog</h1>
                        <!-- end page title -->
                    </div>
                </div>
            </div>
        </section>
        <!-- end page title section -->
<!-- start blog content section --> 
<section>
            <div class="container">
                <div class="row">
                    <main class="col-12 col-lg-9 right-sidebar md-margin-60px-bottom sm-margin-40px-bottom md-padding-15px-lr">
                        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <!-- start post item --> 
                        <div class="blog-post-content d-flex align-items-center flex-wrap margin-60px-bottom padding-60px-bottom border-bottom border-color-extra-light-gray md-margin-30px-bottom md-padding-30px-bottom text-center text-md-left md-no-border">
                            <div class="col-12 col-lg-5 blog-image p-0 md-margin-30px-bottom sm-margin-20px-bottom margin-45px-right md-no-margin-right">
                                <a href="<?php echo e(url('blog/'.$post->id.'/'.$post->titre)); ?>"><img src="<?php if($post->photo): ?> <?php echo e(asset('storage/'.$post->photo)); ?> <?php else: ?> <?php echo e(asset('assets/images/default.png')); ?> <?php endif; ?>" alt="<?php echo e($post->titre); ?>" ></a>
                            </div>
                            <div class="col-12 col-lg-6 blog-text p-0">
                                <div class="content margin-20px-bottom md-no-padding-left ">
                                    <a href="<?php echo e(url('blog/'.$post->id.'/'.$post->titre)); ?>" class="text-extra-dark-gray margin-5px-bottom alt-font text-extra-large font-weight-600 d-inline-block"><?php echo e($post->titre); ?></a>
                                    <div class="text-medium-gray text-extra-small margin-15px-bottom text-uppercase alt-font"><span><?php echo e(date('Y-m-d', strtotime($post->created_at))); ?></span>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;<a href="blog-grid.html" class="text-medium-gray"><?php echo e($post->categorie->libelle); ?></a></div>
                                    <p class="m-0 width-95"><?php echo e(substr($post->description,0,155).'...'); ?></p>
                                </div>
                                <a class="btn btn-very-small btn-dark-gray text-uppercase" href="<?php echo e(url('blog/'.$post->id.'/'.$post->titre)); ?>">Voir Plus</a>
                            </div>
                        </div>
                        <!-- end post item -->  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p>Aucun Article existe</p>
                        <?php endif; ?>
                      
                    </main>
                    <aside class="col-12 col-lg-3">
                        <div class="d-inline-block width-100 margin-45px-bottom sm-margin-25px-bottom">
                            <form method="get" action="<?php echo e(url('blog')); ?>">
                                <div class="position-relative">
                                    <input type="text" name="search" class="bg-transparent text-small m-0 border-color-extra-light-gray medium-input float-left" value="<?php echo e(request()->get('search')); ?>" placeholder="Chercher...">
                                    <button type="submit" class="bg-transparent  btn position-absolute right-0 top-1"><i class="fas fa-search ml-0"></i></button>
                                </div>   
                            </form>
                        </div>
                        
                        <div class="margin-50px-bottom">
                            <div class="text-extra-dark-gray margin-20px-bottom alt-font text-uppercase font-weight-600 text-small aside-title"><span>Suivez Nous</span></div>
                            <div class="social-icon-style-1 text-center">
                                <ul class="extra-small-icon">
                                    <li><a class="facebook" href="https://www.facebook.com/WEB-IDEAL-112485187066689" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a class="twitter" href="https://twitter.com/webideal1" target="_blank"><i class="fab fa-twitter"></i></a></li>
                                    <li><a class="instagram" href="https://www.instagram.com/web_ideal" target="_blank"><i class="fab fa-instagram"></i></a></li>
                                    
                                    <li><a class="linkedin" href="https://www.linkedin.com/in/web-ideal-ab71251a6/" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                                     
                                </ul>
                            </div>
                        </div>
                        <div class="margin-45px-bottom sm-margin-25px-bottom">
                            <div class="text-extra-dark-gray margin-20px-bottom alt-font text-uppercase font-weight-600 text-small aside-title"><span>Categories</span></div>
                            <ul class="list-style-6 margin-50px-bottom text-small">
                                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li><a href="<?php echo e(url('blog?cat='.$cat->libelle)); ?>"><?php echo e($cat-> libelle); ?></a><span><?php echo e(count($cat->posts)); ?></span></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li>Aucun Catégorie existe !</li>
                                <?php endif; ?>
                                
                            </ul>   
                        </div>
                        <div class="bg-deep-pink padding-30px-all text-white-2 text-center margin-45px-bottom sm-margin-25px-bottom">
                            <i class="fas fa-quote-left icon-small margin-15px-bottom d-block"></i>
                            <span class="text-extra-large font-weight-300 margin-20px-bottom d-block">The future belongs to those who believe in the beauty of their dreams.</span>
                            <a class="btn btn-very-small btn-transparent-white border text-uppercase" href="<?php echo e(url('portfolio')); ?>">Explore Portfolio</a>
                        </div>
                        <div class="margin-45px-bottom sm-margin-25px-bottom">
                            <div class="text-extra-dark-gray margin-25px-bottom alt-font text-uppercase font-weight-600 text-small aside-title"><span>tags</span></div>
                            <div class="tag-cloud">
                                <?php $__empty_1 = true; $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <a href="<?php echo e(url('blog?tag='.$tag->libelle)); ?>"><?php echo e(strtoupper($tag->libelle)); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li>Aucun Catégorie existe !</li>
                                <?php endif; ?>

                            </div>
                        </div>
                        <div class="margin-45px-bottom sm-margin-25px-bottom">
                            <div class="text-extra-dark-gray margin-25px-bottom alt-font text-uppercase font-weight-600 text-small aside-title"><span>Archive</span></div>
                            <ul class="list-style-6 margin-20px-bottom text-small">
                                <?php 
                                    $currentDate = Carbon\Carbon::now();
                                    $cpt = $currentDate->month;
                                    while ( $cpt >= 1) {
                                        $dateWithMonth = $currentDate->year."-".$cpt.'-01';
                                        echo "<li><a href='". url('blog?date='.$currentDate->year."-".$cpt)."'>". ucfirst(Carbon\Carbon::parse($dateWithMonth)->isoFormat('MMMM')) .' '.$currentDate->year."</a></li>";
                                       $cpt -- ;
                                    }
                                ?>
                            </ul>   
                        </div>
                    </aside>
                </div>
            </div>
        </section>
        <!-- end blog content section -->  
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\wamp64\www\webideal\resources\views/public/blog.blade.php ENDPATH**/ ?>