<div class="row">
    <div class="col-md-6">
        <div class="form-group row <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
            <label for="name" class="col-md-3 col-form-label"><?php echo e('Name'); ?></label>
        	<div class="col-md-9">
            	<input class="form-control" name="name" type="text" id="name" value="<?php echo e(isset($user->name) ? $user->name : old('name')); ?>" >

            <?php echo $errors->first('name', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group row <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
            <label for="email" class="col-md-3 col-form-label"><?php echo e('Email'); ?></label>
        	<div class="col-md-9">
            	<input class="form-control" name="email" type="text" id="email" value="<?php echo e(isset($user->email) ? $user->email : old('email')); ?>" >

            <?php echo $errors->first('email', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-6">
        <?php if(isset($user)): ?>
            <div class="form-group row <?php echo e($errors->has('mycheckbox') ? 'has-error' : ''); ?>">
                <label for="mycheckbox" class="col-md-3 col-form-label"><?php echo e('Modifier Mot de Passe'); ?></label>
                <div class="col-md-9">
                   <label> <input type="checkbox"  id="mycheckbox" class="i-checks" name="mycheckbox" >   </label>
                </div>
            </div>                                
        <?php endif; ?>
        <div style="<?php echo e((@$user) ? 'display: none;' : ''); ?>" id="SectionPassword" class="form-group row <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
            <label for="password" class="col-md-3 col-form-label"><?php echo e('Mot de passe'); ?></label>
        	<div class="col-md-9">
            	<input class="form-control" name="password" type="password" id="password" value="<?php echo e(old('password')); ?>" >

            <?php echo $errors->first('password', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>

        <div class="form-group row <?php echo e($errors->has('role_id') ? 'has-error' : ''); ?>">
            <label for="role_id" class="col-md-3 col-form-label"><?php echo e('Role'); ?></label>
            <div class="col-md-9">
                <select class="select2 form-control custom-select" required id="role_id" name="role_id" style="width: 100%; height:36px;">
                    <option value="" selected>Selectionnez</option>
                    <?php if(count($roles)): ?>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(isset($user->role_id) && $item->id == $user->role_id): ?>
                                <option selected value="<?php echo e($item->id); ?>"><?php echo e($item->libelle); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->libelle); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
                 <label for="role_id" generated="true" class="error" style="display: none;"></label>

            <?php echo $errors->first('role_id', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
</div>


<div class="form-group row">
    <div class="col-sm-4 col-sm-offset-2">
        <button class="btn btn-primary btn-sm" type="submit"><?php echo e($formMode === 'edit' ? 'Modifier' : 'Ajouter'); ?></button>
    </div>
</div>

<?php /**PATH C:\wamp64\www\webideals\resources\views/admin/users/form.blade.php ENDPATH**/ ?>