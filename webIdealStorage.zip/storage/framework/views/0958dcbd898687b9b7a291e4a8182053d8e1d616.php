<div class="form-group row <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
    <label for="email" class="col-sm-2 col-form-label"><?php echo e('Email'); ?></label>
	<div class="col-sm-10">
    	<input class="form-control" name="email" type="text" id="email" value="<?php echo e(isset($mailing->email) ? $mailing->email : old('email')); ?>" >

    <?php echo $errors->first('email', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group row <?php echo e($errors->has('nom') ? 'has-error' : ''); ?>">
    <label for="nom" class="col-sm-2 col-form-label"><?php echo e('Nom'); ?></label>
	<div class="col-sm-10">
    	<input class="form-control" name="nom" type="text" id="nom" value="<?php echo e(isset($mailing->nom) ? $mailing->nom : old('nom')); ?>" >

    <?php echo $errors->first('nom', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<?php if(isset($mailing)): ?>
<div class="form-group row <?php echo e($errors->has('etat') ? 'has-error' : ''); ?>">
    <label for="etat" class="col-sm-2 col-form-label"><?php echo e('Etat'); ?></label>
	<div class="col-sm-10">
        <select name="etat" id="etat"  class="form-control">
            <option>Selectionez une Catégorie</option>
            <option <?=(isset($mailing->etat) && $mailing->etat=="Validé") ? 'selected' : '' ?> value="Validé">Validé</option>
            <option <?=(isset($mailing->etat) && $mailing->etat=="Non Validé") ? 'selected' : '' ?> value="Non Validé">Non Validé</option>

        </select>

    <?php echo $errors->first('etat', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<?php endif; ?>



<div class="form-group row">
    <div class="col-sm-4 col-sm-offset-2">
        <button class="btn btn-primary btn-sm" type="submit"><?php echo e($formMode === 'edit' ? 'Modifier' : 'Ajouter'); ?></button>
    </div>
</div>

<?php /**PATH C:\wamp64\www\webideals\resources\views/admin/mailings/form.blade.php ENDPATH**/ ?>