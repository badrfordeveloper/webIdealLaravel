 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.master','data' => []]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <div class="container">
        <div class="row">

            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Post <?php echo e($post->id); ?></div>
                    <div class="card-body">

                        <a href="<?php echo e(url('/admin/posts')); ?>" title="Back"><button class="btn btn-warning btn-sm"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                        <a href="<?php echo e(url('/admin/posts/' . $post->id . '/edit')); ?>" title="Edit Post"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</button></a>

                        <form method="POST" action="<?php echo e(url('admin/posts' . '/' . $post->id)); ?>" accept-charset="UTF-8" style="display:inline">
                            <?php echo e(method_field('DELETE')); ?>

                            <?php echo e(csrf_field()); ?>

                            <button type="submit" class="btn btn-danger btn-sm" title="Delete Post" onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash-o" aria-hidden="true"></i> Delete</button>
                        </form>
                        <br/>
                        <br/>

                        <div class="table-responsive">
                            <table class="table">
                                <tbody>
                                    <tr>
                                        <td colspan="2" style="text-align:center"> <img height="150px;" src="<?php if($post->photo): ?> <?php echo e(asset('storage/'.$post->photo)); ?> <?php else: ?> <?php echo e(asset('assets/images/default.png')); ?> <?php endif; ?>" alt="<?php echo e($post->titre); ?>"> </td>
                                    </tr>
                                    <tr>
                                        <th>ID</th><td><?php echo e($post->id); ?></td>
                                    </tr>
                                    <tr>
                                        <th> Titre </th><td> <?php echo e($post->titre); ?> </td>
                                    </tr>
                                    <tr>
                                        <th> Content </th><td> <?php echo $post->content; ?> </td>
                                    </tr>
                                    
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\wamp64\www\webideal\resources\views/admin/post/posts/show.blade.php ENDPATH**/ ?>