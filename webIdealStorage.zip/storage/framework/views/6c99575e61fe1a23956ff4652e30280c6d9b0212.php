<div class="form-group <?php echo e($errors->has('libelle') ? 'has-error' : ''); ?>">
    <label for="libelle" class="control-label"><?php echo e('Libelle'); ?></label>
    <input class="form-control" name="libelle" type="text" id="libelle" value="<?php echo e(isset($category->libelle) ? $category->libelle : ''); ?>" >
    <?php echo $errors->first('libelle', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
<?php /**PATH C:\wamp64\www\webideals\resources\views/admin/categorie/categories/form.blade.php ENDPATH**/ ?>