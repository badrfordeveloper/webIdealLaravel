<div class="form-group <?php echo e($errors->has('titre') ? 'has-error' : ''); ?>">
    <label for="titre" class="control-label"><?php echo e('Titre'); ?></label>
    <input class="form-control" name="titre" type="text" id="titre" value="<?php echo e(isset($post->titre) ? $post->titre : ''); ?>" >
    <?php echo $errors->first('titre', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
    <label for="description" class="control-label"><?php echo e('Description'); ?></label>
    <textarea class="form-control" rows="5" name="description" type="textarea" id="description" ><?php echo e(isset($post->description) ? $post->description : ''); ?></textarea>
    <?php echo $errors->first('description', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('content') ? 'has-error' : ''); ?>">
    <label for="content" class="control-label"><?php echo e('Content'); ?></label>
    <textarea class="form-control" rows="5" name="content" type="textarea" id="content" ><?php echo e(isset($post->content) ? $post->content : ''); ?></textarea>
    <?php echo $errors->first('content', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('photo') ? 'has-error' : ''); ?>">
    <label for="photo" class="control-label"><?php echo e('Photo'); ?></label>
    <input class="form-control" name="photo" type="file" id="photo" value="<?php echo e(isset($post->photo) ? $post->photophoto : ''); ?>" >
    <?php echo $errors->first('photo', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('categorie_id') ? 'has-error' : ''); ?>">
    <label for="categorie_id" class="control-label"><?php echo e('Categorie Id'); ?></label>
    <select name="categorie_id" id="categorie_id"  class="form-control">

        <option>Selectionez une Catégorie</option>
        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php if(isset($post->categorie_id) && $post->categorie_id == $cat->id): ?>
                <option selected value="<?php echo e($cat->id); ?>"><?php echo e($cat-> libelle); ?></option>
            <?php else: ?>
                <option  value="<?php echo e($cat->id); ?>"><?php echo e($cat-> libelle); ?></option>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>

    </select>
    <?php echo $errors->first('categorie_id', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group <?php echo e($errors->has('tag_id') ? 'has-error' : ''); ?>">
    <label for="tag_id" class="control-label"><?php echo e('tags'); ?></label>
    <select  id="tag_id"  class="js-example-basic-single js-states form-control" name="tags[]" multiple  style="width: 100%; height:150px;" size="10">

        <?php $__empty_1 = true; $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <option 

            <?php if(isset($tagsPost)): ?>

                <?php $__empty_2 = true; $__currentLoopData = $tagsPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tagpost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                    <?php if(  $tag->id == $tagpost->tag_id): ?>
                        selected                    

                    <?php endif; ?>
                  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                
                <?php endif; ?>
            <?php endif; ?>



            value="<?php echo e($tag->id); ?>"><?php echo e($tag-> libelle); ?></option>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>





    </select>
    <?php echo $errors->first('tag_id', '<p class="help-block">:message</p>'); ?>

</div>

<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
<?php /**PATH C:\wamp64\www\webideal\resources\views/admin/post/posts/form.blade.php ENDPATH**/ ?>