
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-lg-12">
                <div class="ibox ">
                    <div class="ibox-title">
                        <h5>Mailing</h5>
                        <div class="ibox-tools">
                               <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    </div>
                    <div class="ibox-content  text-center">

                       

                        <div class="table-responsive">
                            <table class="table table-striped table-bordered table-hover">
                                <tbody>
                                    <tr><th> Email </th><td> <?php echo e($mailing->email); ?> </td></tr><tr><th> Nom </th><td> <?php echo e($mailing->nom); ?> </td></tr><tr><th> Etat </th><td> <?php echo e($mailing->etat); ?> </td></tr>
                                    <tr>
                                        <th>Nombre d'evoi</th><td><?php echo e($mailing->nb_email ?? '0'); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <?php if(App\Helpers\Checker::checkAcces('mailings','edit')): ?> 

                         <a href="<?php echo e(url('/admin/mailings/' . $mailing->id . '/edit')); ?>" title="Edit Mailing"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Editer</button></a>
                          <?php endif; ?>


                        <div class="table-responsive" style="display:inline">
                        <?php if(App\Helpers\Checker::checkAcces('mailings','destroy')): ?> 

                        <form method="POST" action="<?php echo e(url('admin/mailings' . '/' . $mailing->id)); ?>" accept-charset="UTF-8" style="display:inline">
                            <?php echo e(method_field('DELETE')); ?>

                            <?php echo e(csrf_field()); ?>

                            <button type="submit" class="btn btn-danger btn-sm" title="Delete Mailing" onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash-o" aria-hidden="true"></i> Supprimer</button>
                        </form>
                         <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>


<?php /**PATH C:\wamp64\www\webideals\resources\views/admin/mailings/show.blade.php ENDPATH**/ ?>