<div class="form-group row <?php echo e($errors->has('libelle') ? 'has-error' : ''); ?>">
    <label for="libelle" class="col-sm-2 col-form-label"><?php echo e('Libelle'); ?></label>
	<div class="col-sm-10">
    	<input class="form-control" name="libelle" type="text" id="libelle" value="<?php echo e(isset($role->libelle) ? $role->libelle : old('libelle')); ?>" >

    <?php echo $errors->first('libelle', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<table class="table">
    <?php $__currentLoopData = $accestable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $at): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <th><?php echo e(ucfirst($at->table)); ?></th>
        <?php $__currentLoopData = $acces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($ac->table == $at->table): ?>
	        <?php if( @in_array($ac->id,$accesByRole) ): ?>
	        <td class="text-center">
	            <div class="custom-control custom-checkbox mr-sm-2">
	                <input type="checkbox" checked name="acces[]" class="custom-control-input" id="customControlAutosizing<?php echo e($ac->id); ?>"  value="<?php echo e($ac->id); ?>"  >
	                <label class="custom-control-label" for="customControlAutosizing<?php echo e($ac->id); ?>"> <?php echo e(ucfirst($ac->action)); ?></label>
	            </div>
	         </td>
	         <?php else: ?>
	         <td class="text-center">
	            <div class="custom-control custom-checkbox mr-sm-2">
	                <input type="checkbox" name="acces[]" class="custom-control-input" id="customControlAutosizing<?php echo e($ac->id); ?>"  value="<?php echo e($ac->id); ?>"  >
	                <label class="custom-control-label" for="customControlAutosizing<?php echo e($ac->id); ?>"> <?php echo e(ucfirst($ac->action)); ?></label>
	            </div>
	         </td>
	         <?php endif; ?>

        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>


<div class="form-group row">
    <div class="col-sm-4 col-sm-offset-2">
        <button class="btn btn-primary btn-sm" type="submit"><?php echo e($formMode === 'edit' ? 'Modifier' : 'Ajouter'); ?></button>
    </div>
</div>

<?php /**PATH C:\wamp64\www\webideals\resources\views/admin/roles/form.blade.php ENDPATH**/ ?>